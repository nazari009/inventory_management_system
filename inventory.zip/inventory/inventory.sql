-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 30, 2021 at 06:18 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `emp_id` int(50) NOT NULL auto_increment,
  `emp_name` varchar(50) collate utf8_persian_ci NOT NULL,
  `emp_fname` varchar(50) collate utf8_persian_ci NOT NULL,
  `emp_surname` varchar(50) collate utf8_persian_ci NOT NULL,
  `emp_job` varchar(50) collate utf8_persian_ci NOT NULL,
  PRIMARY KEY  (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`emp_id`, `emp_name`, `emp_fname`, `emp_surname`, `emp_job`) VALUES
(1, 'سفتر', 'قربان', 'صادقی', 'مدیر تدارکات'),
(2, 'سخی', 'موسا', 'ظفر', 'مدیر ترکاری فروشها'),
(3, 'حسین بخش', '', '', ''),
(4, 'حسین بخش', 'ناظر', 'صفری', 'ورزشکار'),
(5, 'علی پور', 'گل محمد', 'علی پور', 'قومندان'),
(6, 'hussain', 'asad', 'nazari', 'stu'),
(7, 'صمیم', 'قدرت', 'مرادی', 'استاد'),
(8, 'hdkfhdks', 'sdfdsf', 'dfdf', 'f'),
(9, 'sssss', 'sssssss', 'ssssssss', 'aaa'),
(10, 'john', 'tiger', 'cena', 'athelate'),
(11, 'ramin', 'ramazzan', 'ebrahmim', 'atu'),
(12, '', '', '', ''),
(13, 'حسین بخش', 'ناظر', 'صفری', 'ورزشکار');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(50) collate utf8_persian_ci NOT NULL,
  `item_price` int(11) NOT NULL,
  `item_date` date NOT NULL,
  `item_emp_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `item_price`, `item_date`, `item_emp_id`) VALUES
(1, 'لپتاپ', 200, '2020-02-02', 1),
(2, 'کتاب', 2000, '2020-02-22', 2);
