<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Inventory System</title>

    <!-- Bootstrap -->
    <link href="boot/css/bootstrap.css" rel="stylesheet" >
    <link href="boot/css/mycss.css" rel="stylesheet" >
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="boot/js/html5shiv.min.js"></script>
      <script src="boot/js/respond.min.js"></script>
    <![endif]-->
  </head>
    <body>
     <div class="container-fluid">
    <!--first row-->
     <div clas="row" id="top">
        <div class="col-md-3" id="logo">
       <img class="img-responsive" src="img/mylogo.png" alt="logo" />
        </div>
        <div class="col-md-6">
        </div>
         <div class="col-md-3" id="dept_name"><h1>خدمات نرم افزاری</h1>
         </div>
     </div>
      <!--end of first row-->
        <br/>