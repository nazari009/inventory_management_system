<?php
$c =mysqli_connect("localhost","root","","inventory");

     if(!$c){
		 die("connection failed".mysql_connect_error());
         }
mysqli_set_charset($c,"utf8");
?>