    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="boot/js/jquery-1.12.4.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="boot/js/bootstrap.min.js"></script>
      <script src="boot/js/myscript.js"></script>
  </body>
</html>