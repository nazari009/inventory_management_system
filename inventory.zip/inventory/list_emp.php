<?php
include("include/connection.php");
include("include/header.php");
if(!empty($_POST['search'])){
    $search = $_POST['search'];
    $swl = "SELECT * FROM employees";
    $swl .= " WHERE CONCAT(emp_name,emp_fname,emp_surname,emp_job) like '%$search%'";


$result = mysqli_query($c,$swl);
}else{
    $swl = "SELECT * FROM employees";
$result = mysqli_query($c,$swl);
}

?>
       <div clas="row">
        <div class="col-md-4" id="menu">
           <ul class="nav nav-pills">
             <li role="presentation" class="active"><a href="add_item.php">جنس جدید</a></li>
             <li role="presentation"><a href="add_emp.php">کارمند جدید</a></li>
             <li role="presentation"><a href="index.php">لیست اجناس</a></li> 
         </ul></div>
        <div class="col-md-6">
             <form class="form-inline" action="" method="post">
             <div class="form-group" id="fsearch">
                <input type="text" class="form-control" name="search" placeholder="جستجو">
                 <button type="submit" class="btn btn-info">جستجو</button>
             </div>
        </form>
           </div>
        <div class="col-md-2">
            <h2 class="title">لیست کارمندان</h2></div>
    </div>
        <br/>
     <div clas="row">
        <div class="col-md-12" id="content">
         <table class="table table-striped" dir="rtl">
            <thead>
              <tr class="info">
                <th>نام کارمند</th>
                <th>نام پدر</th>
                <th>تخلص</th>
                <th>وظیفه</th>
                <th>عملیات</th>
               </tr>
            </thead>
            <tbody>
                <?php
               
                if(mysqli_num_rows($result)>0){
                    while($row = mysqli_fetch_row($result)){
                        echo"<tr>";
                            echo"<td>".$row[1]."</td>";
                            echo"<td>".$row[2]."</td>";
                            echo"<td>".$row[3]."</td>";
                            echo"<td>".$row[4]."</td>";
                            echo"<td><a href='edit_emp.php?id=".$row[1]."'>اصلاح</a></td>";
                        echo"</tr>";
                        
                    }
                }
                ?>
             </tbody>
         </table></div>
    </div>
    </div> 

